﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Xml.Serialization;

namespace RecorderDrawer
{
    [Serializable]
    public class RecordData : IComparable<RecordData>
    {
        public DateTime Date { get; private set; }
        public List<float> Parameter { get; private set; }

        public RecordData()
        {
            Date = DateTime.Now;
            Parameter = new List<float>();
        }

        public RecordData(DateTime date, List<float> parameter)
        {
            Date = date;
            Parameter = parameter.ToList();
        }

        public int CompareTo(RecordData obj)
        {
            if (obj == null)
                return -1;
            else
                return Date.CompareTo(obj.Date);
        }

        public void Serialize(Stream output)
        {
            BinaryWriter writer = new BinaryWriter(output);
            writer.Write(Date.Ticks);
            writer.Write(Parameter.Count);
            foreach (float item in Parameter)
                writer.Write(item);
            writer.Flush();
        }

        public static RecordData Deserialize(Stream input)
        {
            BinaryReader reader = new BinaryReader(input);
            DateTime date = new DateTime(reader.ReadInt64());
            int count = reader.ReadInt32();
            List<float> parameter = new List<float>();
            for (int i = 0; i < count; i++)
                parameter.Add(reader.ReadSingle());
            return new RecordData(date, parameter);
        }
    }
}
