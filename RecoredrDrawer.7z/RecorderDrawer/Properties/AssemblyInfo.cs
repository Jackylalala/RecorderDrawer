﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Resources;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("高壓反應器趨勢圖繪圖程式")]
[assembly: AssemblyDescription("繪製反應趨勢圖")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("jackylalala2@gmail.com")]
[assembly: AssemblyProduct("高壓反應器趨勢圖繪圖程式")]
[assembly: AssemblyCopyright("Mon-Wei Hsiao Copyright ©  2015 - 2018")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("2f2f3cc0-f92c-4bde-a756-b28ebe6b5332")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Build and Revision Numbers 
// by using the '*' as shown below:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("8.1.*")]
[assembly: AssemblyFileVersion("8.1")]
[assembly: NeutralResourcesLanguageAttribute("zh-TW")]
