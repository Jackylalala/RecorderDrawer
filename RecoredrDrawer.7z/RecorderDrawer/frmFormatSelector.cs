﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace RecorderDrawer
{
    public partial class frmFormatSelector : Form
    {
        #region | Fields |
        //Controls
        private TextBox[] txtTitle = new TextBox[6];
        private ComboBox[] cboUnit = new ComboBox[6];
        private TextBox[] txtMin = new TextBox[6];
        private TextBox[] txtMax = new TextBox[6];
        private TextBox[] txtInterval = new TextBox[6];
        private List<Label> lblAxis = new List<Label>();
        private List<ComboBox> cboAxis = new List<ComboBox>();
        #endregion

        #region | Property |
        public AxesProp[] YProp { get; private set; }
        public int XType { get; private set; }
        public int XInterval { get; private set; }
        public int XAngle { get; private set; }
        public int[][] SeriesMap;
        #endregion

        public frmFormatSelector(string[] previewData)
        {
            InitializeComponent();
            //Init. componment
            for (int i = 0; i < 6; i++)
            {
                txtTitle[i] = new TextBox();
                txtTitle[i].Text = frmRecorderDrawer.YProp[i].Title;
                txtTitle[i].MaxLength = 4;
                txtTitle[i].TextAlign = HorizontalAlignment.Center;
                tblMain.Controls.Add(txtTitle[i], 1, i + 1);
                cboUnit[i] = new ComboBox();
                cboUnit[i].Items.AddRange(frmRecorderDrawer.unitList);
                cboUnit[i].SelectedIndex = frmRecorderDrawer.YProp[i].Unit;
                cboUnit[i].DropDownStyle = ComboBoxStyle.DropDownList;
                tblMain.Controls.Add(cboUnit[i], 2, i + 1);
                txtMin[i] = new TextBox();
                txtMin[i].Text = frmRecorderDrawer.YProp[i].Min.ToString(); ;
                txtMin[i].KeyPress += InputOnlyNumber;
                txtMin[i].Dock = DockStyle.Fill;
                txtMin[i].TextAlign = HorizontalAlignment.Center;
                tblMain.Controls.Add(txtMin[i], 3, i + 1);
                txtMax[i] = new TextBox();
                txtMax[i].Text = frmRecorderDrawer.YProp[i].Max.ToString();
                txtMax[i].KeyPress += InputOnlyNumber;
                txtMax[i].Dock = DockStyle.Fill;
                txtMax[i].TextAlign = HorizontalAlignment.Center;
                tblMain.Controls.Add(txtMax[i], 4, i + 1);
                txtInterval[i] = new TextBox();
                txtInterval[i].Text = frmRecorderDrawer.YProp[i].Interval.ToString();
                txtInterval[i].KeyPress += InputOnlyNumber;
                txtInterval[i].Dock = DockStyle.Fill;
                txtInterval[i].TextAlign = HorizontalAlignment.Center;
                tblMain.Controls.Add(txtInterval[i], 5, i + 1);
            }
            cboXAngle.Items.Clear();
            for (int i = -90; i <= 90; i += 5)
                cboXAngle.Items.Add(i);
            cboXType.SelectedIndex = frmRecorderDrawer.XType;
            if (frmRecorderDrawer.XInterval == 0)
                cboXInterval.SelectedIndex = 0;
            else
                cboXInterval.SelectedItem = frmRecorderDrawer.XInterval.ToString();
            cboXAngle.SelectedItem = frmRecorderDrawer.XAngle;
            //set tooltip
            ToolTip tooltip = new ToolTip();
            tooltip.SetToolTip(lblAxe1, "請將此座標軸設定為內溫資訊");
            tooltip.SetToolTip(lblAxe2, "請將此座標軸設定為外溫資訊");
            tooltip.SetToolTip(lblAxe3, "請將此座標軸設定為壓力資訊");
            tooltip.SetToolTip(lblAxe4, "請將此座標軸設定為流速資訊");
            tooltip.SetToolTip(lblAxe5, "此座標軸可設定為任意資訊");
            tooltip.SetToolTip(lblAxe6, "此座標軸可設定為任意資訊");
            //preview data
            for (int i = 0; i < previewData[0].Split(',', '\t').Length; i++)
                dgvMain.Columns.Add("#" + i, "#" + i);
            foreach (DataGridViewColumn col in dgvMain.Columns)
                col.SortMode = DataGridViewColumnSortMode.NotSortable;
            for (int i = 0; i < 51; i++)
                dgvMain.Rows.Add(previewData[i].Split(',', '\t'));
            //channel tab
            for (int i = 0; i < previewData[0].Split(',', '\t').Length; i++)
            {
                Label lbl = new Label();
                lbl.Font = new Font("微軟正黑體", 10);
                lbl.AutoSize = false;
                lbl.TextAlign = ContentAlignment.MiddleCenter;
                lbl.Text = "#" + i;
                lbl.Location = new Point(7, 29 + 31 * i);
                lbl.Size = new Size(37, 25);
                pnlChannel.Controls.Add(lbl);
                ComboBox cbo = new ComboBox();
                cbo.Font = new Font("微軟正黑體", 10);
                cbo.DropDownStyle = ComboBoxStyle.DropDownList;
                cbo.Items.AddRange(new object[] { "無", "時間", "內溫軸", "外溫軸", "壓力軸", "流速軸", "任意軸1", "任意軸2" });
                cbo.Location = new Point(44, 29 + 31 * i);
                cbo.Size = new Size(115, 25);
                cbo.SelectedIndex = 0;
                pnlChannel.Controls.Add(cbo);
            }
        }

        public void InputOnlyNumber(object sender, KeyPressEventArgs e)
        {
            //only allow integer (no decimal point)
            if (!char.IsDigit(e.KeyChar) && (e.KeyChar != '.') && (e.KeyChar != '-') && (e.KeyChar != 8))
                e.Handled = true;
            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
                e.Handled = true;
            // only allow sign symbol at first char
            if ((e.KeyChar == '-') && ((sender as TextBox).Text.IndexOf('-') > -1))
                e.Handled = true;
            if ((e.KeyChar == '-') && !((sender as TextBox).Text.IndexOf('-') > -1) && ((sender as TextBox).SelectionStart != 0))
                e.Handled = true;
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 6; i++)
                YProp[i] = new AxesProp(txtTitle[i].Text, cboUnit[i].SelectedIndex, float.Parse(txtMin[i].Text), float.Parse(txtMax[i].Text), float.Parse(txtInterval[i].Text));
            XType = cboXType.SelectedIndex;
            if (cboXInterval.SelectedIndex == 0)
                XInterval = 0;
            else
                XInterval = int.Parse(cboXInterval.SelectedItem.ToString());
            XAngle = (int)cboXAngle.SelectedItem;
            //commit
            DialogResult = DialogResult.OK;
        }
    }
}
